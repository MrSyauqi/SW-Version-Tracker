"""
SW Version Tracker - Local Server with SQLite
Run: python server.py
Then open: http://localhost:5000
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import subprocess, json, os, sqlite3, urllib.parse, base64, re, time

PORT = 5000
DB_FILE = "tracker.db"
UPLOADS_DIR = "uploads"

# ---------- DB ----------

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(UPLOADS_DIR, exist_ok=True)
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ver TEXT NOT NULL,
            details TEXT DEFAULT '',
            case_id TEXT DEFAULT '',
            customer TEXT DEFAULT '',
            issue TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            images TEXT DEFAULT '[]',
            path TEXT NOT NULL,
            status TEXT DEFAULT 'workable',
            category TEXT DEFAULT 'AOI',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )
    """)
    # Migrations
    cols = [r[1] for r in conn.execute("PRAGMA table_info(entries)").fetchall()]
    for col, defn in [
        ("notes",    "TEXT DEFAULT ''"),
        ("images",   "TEXT DEFAULT '[]'"),
        ("status",   "TEXT DEFAULT 'workable'"),
        ("category", "TEXT DEFAULT 'AOI'"),
        ("paths",    "TEXT DEFAULT '[]'"),   # JSON: [{label, path}]
    ]:
        if col not in cols:
            conn.execute(f"ALTER TABLE entries ADD COLUMN {col} {defn}")
            print(f"  [DB] Migrated: added '{col}'")

    # If upgrading from old single-path DB, migrate path -> paths
    cols_now = [r[1] for r in conn.execute("PRAGMA table_info(entries)").fetchall()]
    if "path" in cols_now and "paths" in cols_now:
        rows_to_migrate = conn.execute("SELECT id, path, paths FROM entries WHERE paths='[]' AND path!=''").fetchall()
        for row in rows_to_migrate:
            import json as _json
            label = row[1].split("\\")[-1] if row[1] else ""
            new_paths = _json.dumps([{"label": label, "path": row[1]}])
            conn.execute("UPDATE entries SET paths=? WHERE id=?", (new_paths, row[0]))
        if rows_to_migrate:
            print(f"  [DB] Migrated {len(rows_to_migrate)} entries: path -> paths")

    # Seed categories
    cats = [r[0] for r in conn.execute("SELECT name FROM categories").fetchall()]
    for c in ["AOI", "SPI", "MES"]:
        if c not in cats:
            conn.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (c,))

    # Seed entries
    if conn.execute("SELECT COUNT(*) FROM entries").fetchone()[0] == 0:
        import json as _json
        seed = [
            ("2.9.10","setup_x64_2.9.10.0-8-\nsetup_x64_2.9.10.0-8","CAS-22528-N2D9","Bangkok (Factory 7)",
             "Delta7 NPI Order requirement for Max height of 2 component groups","","[]",
             "D:\\[1] AOI\\[1] All AOI Software\\KY_AOI_v142_setup_x64_2.9.0.0_AL03-42-g4ce9ef70489(B_v2.9.0.0).exe",
             "bug","AOI",
             _json.dumps([{"label":"v2.9.0.0 installer","path":"D:\\[1] AOI\\[1] All AOI Software\\KY_AOI_v142_setup_x64_2.9.0.0_AL03-42-g4ce9ef70489(B_v2.9.0.0).exe"}])),
            ("2.9.5","setup_x64_2.9.6.0-18-g.exe\nsetup_x64_2.9.6.0-1).exe","CAS-22025-Y4C4","Bangkok (Factory 7)",
             "Delta7 BGA product cannot generate real ball shape","","[]",
             "D:\\[1] AOI\\[1] All AOI Software\\KY_AOI_v142_setup_x64_2.9.1.0_AL03-3-g7d3d29a00e9(B_v2.9.1.0).exe",
             "fix","AOI",
             _json.dumps([{"label":"v2.9.1.0 installer","path":"D:\\[1] AOI\\[1] All AOI Software\\KY_AOI_v142_setup_x64_2.9.1.0_AL03-3-g7d3d29a00e9(B_v2.9.1.0).exe"}])),
            ("2.9.5","setup_x64_2.9.6.0-18.exe\nsetup_x64_2.9.6.0-18).exe","","Bangkok (Factory 8)",
             "Shiny object cannot detect","","[]",
             "D:\\[1] AOI\\[1] All AOI Software\\KY_AOI_v142_setup_x64_2.9.1.0_AL03-3-g7d3d29a00e9(B_v2.9.1.0).exe",
             "workable","AOI",
             _json.dumps([{"label":"v2.9.1.0 installer","path":"D:\\[1] AOI\\[1] All AOI Software\\KY_AOI_v142_setup_x64_2.9.1.0_AL03-3-g7d3d29a00e9(B_v2.9.1.0).exe"}])),
        ]
        conn.executemany(
            "INSERT INTO entries (ver,details,case_id,customer,issue,notes,images,path,status,category,paths) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            seed
        )
        print(f"  [DB] Seeded entries.")
    conn.commit()
    conn.close()
    print(f"  [DB] Ready: {os.path.abspath(DB_FILE)}")
    print(f"  [Uploads] {os.path.abspath(UPLOADS_DIR)}")

# ---------- Handler ----------

class Handler(BaseHTTPRequestHandler):

    def do_OPTIONS(self):
        self.send_response(200); self._cors(); self.end_headers()

    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        path, params = p.path, urllib.parse.parse_qs(p.query)

        if path in ("/", "/index.html"):
            self.serve_file("index.html", "text/html")
        elif path == "/api/entries":
            self.api_get_entries(params)
        elif path == "/api/categories":
            self.api_get_categories()
        elif path == "/api/open":
            self.open_explorer(params.get("path", [""])[0])
        elif path.startswith("/uploads/"):
            self.serve_upload(path)
        else:
            self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        body = self.read_body()
        if path == "/api/entries":
            self.api_add_entry(body)
        elif path == "/api/open":
            self.open_explorer(body.get("path", ""))
        elif path == "/api/upload":
            self.api_upload(body)
        elif path == "/api/categories":
            self.api_add_category(body)
        else:
            self.send_json({"error": "Not found"}, 404)

    def do_DELETE(self):
        parts = urllib.parse.urlparse(self.path).path.strip("/").split("/")
        if len(parts) == 3 and parts[1] == "entries":
            self.api_delete_entry(parts[2])
        elif len(parts) == 3 and parts[1] == "categories":
            self.api_delete_category(parts[2])
        else:
            self.send_json({"error": "Not found"}, 404)

    def do_PUT(self):
        parts = urllib.parse.urlparse(self.path).path.strip("/").split("/")
        body = self.read_body()
        if len(parts) == 3 and parts[1] == "entries":
            self.api_update_entry(parts[2], body)
        else:
            self.send_json({"error": "Not found"}, 404)

    # ---- Categories ----

    def api_get_categories(self):
        try:
            conn = get_db()
            rows = conn.execute("SELECT * FROM categories ORDER BY id").fetchall()
            conn.close()
            self.send_json({"categories": [dict(r) for r in rows]})
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    def api_add_category(self, body):
        try:
            name = body.get("name", "").strip()
            if not name:
                return self.send_json({"error": "Name required"}, 400)
            conn = get_db()
            conn.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (name,))
            conn.commit()
            rows = conn.execute("SELECT * FROM categories ORDER BY id").fetchall()
            conn.close()
            self.send_json({"success": True, "categories": [dict(r) for r in rows]})
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    def api_delete_category(self, cid):
        try:
            conn = get_db()
            row = conn.execute("SELECT name FROM categories WHERE id=?", (cid,)).fetchone()
            if row:
                conn.execute("DELETE FROM categories WHERE id=?", (cid,))
                conn.commit()
            conn.close()
            self.send_json({"success": True})
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    # ---- Entries ----

    def api_get_entries(self, params):
        q        = params.get("q",        [""])[0].lower()
        customer = params.get("customer", [""])[0]
        status   = params.get("status",   [""])[0]
        category = params.get("category", [""])[0]
        try:
            conn = get_db()
            rows = conn.execute("SELECT * FROM entries ORDER BY ver DESC, id DESC").fetchall()
            conn.close()
            entries = [dict(r) for r in rows]
            if q:
                entries = [e for e in entries if q in (
                    e["ver"]+e["details"]+e["case_id"]+e["customer"]+e["issue"]+e["path"]
                ).lower()]
            if customer:
                entries = [e for e in entries if e["customer"] == customer]
            if status:
                entries = [e for e in entries if e.get("status","") == status]
            if category:
                entries = [e for e in entries if e.get("category","") == category]
            self.send_json({"entries": entries, "total": len(entries)})
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    def api_add_entry(self, body):
        try:
            conn = get_db()
            cur = conn.execute(
                "INSERT INTO entries (ver,details,case_id,customer,issue,notes,images,path,status,category,paths) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (body.get("ver",""), body.get("details",""), body.get("case_id",""),
                 body.get("customer",""), body.get("issue",""), body.get("notes",""),
                 body.get("images","[]"), body.get("path",""),
                 body.get("status","workable"), body.get("category","AOI"),
                 body.get("paths","[]"))
            )
            conn.commit()
            entry = dict(conn.execute("SELECT * FROM entries WHERE id=?", (cur.lastrowid,)).fetchone())
            conn.close()
            self.send_json({"success": True, "entry": entry}, 201)
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    def api_delete_entry(self, eid):
        try:
            conn = get_db()
            conn.execute("DELETE FROM entries WHERE id=?", (eid,))
            conn.commit(); conn.close()
            self.send_json({"success": True})
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    def api_update_entry(self, eid, body):
        try:
            conn = get_db()
            conn.execute(
                "UPDATE entries SET ver=?,details=?,case_id=?,customer=?,issue=?,notes=?,images=?,path=?,status=?,category=?,paths=? WHERE id=?",
                (body.get("ver",""), body.get("details",""), body.get("case_id",""),
                 body.get("customer",""), body.get("issue",""), body.get("notes",""),
                 body.get("images","[]"), body.get("path",""),
                 body.get("status","workable"), body.get("category","AOI"),
                 body.get("paths","[]"), eid)
            )
            conn.commit()
            entry = dict(conn.execute("SELECT * FROM entries WHERE id=?", (eid,)).fetchone())
            conn.close()
            self.send_json({"success": True, "entry": entry})
        except Exception as ex:
            self.send_json({"error": str(ex)}, 500)

    # ---- Upload ----

    def api_upload(self, body):
        try:
            filename = body.get("filename", "image.png")
            # Sanitize filename
            filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
            base, ext = os.path.splitext(filename)
            if not ext:
                ext = ".png"
            unique_name = f"{base}_{int(time.time()*1000)}{ext}"
            raw_data = body.get("data", "")
            # Strip data URL prefix if present
            if "," in raw_data:
                raw_data = raw_data.split(",", 1)[1]
            img_bytes = base64.b64decode(raw_data)
            fpath = os.path.join(UPLOADS_DIR, unique_name)
            with open(fpath, "wb") as f:
                f.write(img_bytes)
            print(f"  [Upload] Saved: {fpath} ({len(img_bytes)} bytes)")
            self.send_json({"success": True, "url": f"/uploads/{unique_name}", "size": len(img_bytes)})
        except Exception as ex:
            print(f"  [Upload ERROR] {ex}")
            self.send_json({"error": str(ex)}, 500)

    # ---- Open Explorer ----

    def open_explorer(self, path):
        try:
            if not path:
                raise ValueError("No path provided")
            path = os.path.normpath(path)
            if os.path.exists(path):
                target = path
                explorer_cmd = f'explorer.exe /select,"{path}"'
            elif os.path.exists(os.path.dirname(path)):
                target = os.path.dirname(path)
                explorer_cmd = f'explorer.exe "{os.path.dirname(path)}"'
            else:
                target = os.path.dirname(path)
                explorer_cmd = f'explorer.exe "{os.path.dirname(path)}"'

            # PowerShell: open explorer then use shell.AppActivate to bring to front
            # This is faster than Add-Type because it uses the COM object directly
            ps_cmd = (
                f"Start-Process '{explorer_cmd.split()[0]}' -ArgumentList '{' '.join(explorer_cmd.split()[1:])}'; "
                f"Start-Sleep -Milliseconds 1000; "
                f"(New-Object -ComObject Shell.Application).Windows() | "
                f"ForEach-Object {{ $_.Visible = $true }}; "
                f"[System.Runtime.InteropServices.Marshal]::ReleaseComObject((New-Object -ComObject Shell.Application)) | Out-Null"
            )

            # Simpler and more reliable: use VBScript AppActivate
            vbs = "\r\n".join([
                'Set sh = CreateObject("WScript.Shell")',
                f'sh.Run "{explorer_cmd}", 1, False',
                'WScript.Sleep 1200',
                'sh.AppActivate "File Explorer"',
                'WScript.Sleep 200',
                'sh.AppActivate "File Explorer"',  # second call is more reliable
            ])
            vbs_path = os.path.join(
                os.environ.get("TEMP", "C:\\Windows\\Temp"),
                "sw_open.vbs"
            )
            with open(vbs_path, "w") as f:
                f.write(vbs)

            subprocess.Popen(
                ["wscript.exe", vbs_path],
                creationflags=0x08000000  # CREATE_NO_WINDOW — hides the black cmd flash
            )
            self.send_json({"success": True, "message": f"Opened: {path}"})

        except Exception as ex:
            # Hard fallback
            try:
                path = os.path.normpath(path)
                subprocess.Popen(f'explorer /select,"{path}"')
                self.send_json({"success": True, "message": "Opened (fallback)"})
            except Exception as ex2:
                self.send_json({"success": False, "message": str(ex2)}, 500)
            except Exception as ex2:
                self.send_json({"success": False, "message": str(ex2)}, 500)

    # ---- Static ----

    def serve_upload(self, url_path):
        filename = url_path.replace("/uploads/", "")
        fpath = os.path.join(UPLOADS_DIR, filename)
        try:
            with open(fpath, "rb") as f:
                data = f.read()
            ext = filename.rsplit(".", 1)[-1].lower()
            mime = {"png":"image/png","jpg":"image/jpeg","jpeg":"image/jpeg",
                    "gif":"image/gif","webp":"image/webp"}.get(ext, "application/octet-stream")
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", len(data))
            self._cors(); self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self.send_response(404); self.end_headers()

    def serve_file(self, filename, content_type):
        try:
            with open(filename, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", len(content))
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_response(404); self.end_headers()
            self.wfile.write(b"index.html not found")

    def read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if not length: return {}
        try: return json.loads(self.rfile.read(length))
        except Exception as e:
            print(f"  [Body parse error] {e}")
            return {}

    def send_json(self, data, status=200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def log_message(self, fmt, *args):
        print(f"  [{self.address_string()}] {fmt % args}")


if __name__ == "__main__":
    init_db()
    server = HTTPServer(("localhost", PORT), Handler)
    print(f"\n✅  http://localhost:{PORT}")
    print(f"   DB      : {os.path.abspath(DB_FILE)}")
    print(f"   Uploads : {os.path.abspath(UPLOADS_DIR)}")
    print(f"   Ctrl+C to stop\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
